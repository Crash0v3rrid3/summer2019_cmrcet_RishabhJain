#ifndef _COMPILER_H
#define _COMPILER_H

void compile(char *sourceFile, char *destFile);

#endif