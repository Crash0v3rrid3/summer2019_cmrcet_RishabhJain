#ifndef TOKENIZER_H
#define TOKENIZER_H

char **tokenize(char *line, unsigned int *numberOfArgs);

#endif